package com.otamurod.viewpagertablayout.models

import java.io.Serializable

data class User(
    val name:String,
    val img:String
):Serializable