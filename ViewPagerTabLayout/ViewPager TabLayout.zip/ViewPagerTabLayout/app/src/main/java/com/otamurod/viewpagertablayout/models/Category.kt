package com.otamurod.viewpagertablayout.models

data class Category(val title:String, val imageList:ArrayList<String>)